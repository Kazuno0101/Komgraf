nama program
Three Symbols of Japanese Crest 

penulis program
Nuno Alwi Azimah

deskripsi
Program ini dibuat untuk keperluan tugas dari mata pelajaran Komputer Grafik dari Politeknik Negeri Bandung, dalam program ini memuat:
= Bagian Pola dasar dari ketiga japanese crest
= Animasi sederhana dari ketiga japanese crest, yang memanfaatkan fungsi transformasi seperti rotasi, translate, dan scaling.